define({
  "name": "Blog Application",
  "version": "0.0.1",
  "description": "Documentation for the blog app",
  "title": "Blog APIs",
  "url": "http://localhost:3000",
  "sampleUrl": false,
  "defaultVersion": "0.0.0",
  "apidoc": "0.3.0",
  "generator": {
    "name": "apidoc",
    "time": "2019-04-26T20:05:35.798Z",
    "url": "http://apidocjs.com",
    "version": "0.17.7"
  }
});
